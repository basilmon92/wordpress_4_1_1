Please find our support system and documentation here:

http://support.vamtam.com


------------------------------------------------------


How to setup a development environment for the theme:

1. Install node.js (with npm) and php5-cli (at least 5.3)
2. Execute the following in the theme directory

npm install

3. Run grunt dev
4. This will automatically recompile your CSS and JS with your latest settings.